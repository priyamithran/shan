a=int(input())
for i in range(0,a):
    n=int(raw_input())
    m=n
    x=0
    while(m!=0):
        x=m%10+x*10
        m/=10
    if(n==x):
        print "wins"
    else:
        print "losses"
    
