x=int(input())
for y in range(0,x):
    y=int(input())
    a=[]
    a=map(int,raw_input("").split())
    b=min(a)
    a.remove(b)
    c=b+min(a)
    print int(c)
