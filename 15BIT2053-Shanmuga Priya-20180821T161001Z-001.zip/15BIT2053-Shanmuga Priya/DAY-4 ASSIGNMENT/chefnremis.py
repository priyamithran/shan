a=int(input())
for i in range (0,a):
    x,y=raw_input("").split()
    x=int(x)
    y=int(y)
    z=x+y
    if(x>y):
        print x,int(z)
    else:
        print y,int(z)
    
