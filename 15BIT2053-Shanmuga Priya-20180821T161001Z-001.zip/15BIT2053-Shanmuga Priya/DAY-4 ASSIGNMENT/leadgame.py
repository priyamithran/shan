player,winner,a,b=0,True,0,0
for _ in range(input()):
    one,two=map(int,raw_input().split())
    a,b=a+one,b+two
    if(player<abs(a-b)):
        player=abs(a-b)
        if(a>b):
            winner=True
        else:
            winner=False
if(winner):
    print 1,player
else:
    print 2,player
 
