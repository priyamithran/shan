a=int(input())
for i in range (0,a):
    b=int(input())
    s=str(raw_input())
    if('I' in s):
        print "INDIAN"
    elif('Y' in s):
        print "NOT INDIAN"
    elif(('Y'not in s)or('I' not in s)):
        print "NOT SURE"

