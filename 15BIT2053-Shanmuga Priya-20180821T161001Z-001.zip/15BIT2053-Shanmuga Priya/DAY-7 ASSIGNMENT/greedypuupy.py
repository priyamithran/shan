a=int(input())
for i in range (1,a+1):
    x,y=map(int,raw_input().split())
    s=0
    for j in range (1,y+1):
        if ((x%j)>s):
            s=x%j
    print s
    
