a=input("10th percentage:")
a=float(a)
b=input("12th percentage:")
b=float(b)
c=input("entrance xam marks:")
c=int(c)
d=bool(input("r u not an sports player..?:True or False"))
if(d):
    if(a>=80):
        if(b>=75):
            if(c>=80):
                print "admitted"
            else:
                print "not admitted"
        else:
            print "not admitted"
    else:
        print "not admitted"
elif(a>=80):
    if(b>=75):
        if(c>=70):
            print "eligible"
        else:
            print "not eligible"
    else:
        print "not eligible"
