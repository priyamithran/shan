a=int(input())
for i in range(1,a+1):
    n=raw_input()
    c=0
    for y in range (0,len(n)):
        c+=int(n[y])
    print c
