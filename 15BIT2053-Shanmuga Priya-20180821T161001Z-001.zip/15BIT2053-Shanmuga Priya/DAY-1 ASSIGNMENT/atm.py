a,b=raw_input("").split()
a=int(a)
b=float(b)
if((a<=2000)and(a>0)):
    if((b<=2000)and(b>0)):
       if((a%5)==0)and(a<=b-0.5):
         c=b-a-0.5
         print ("%.2f" %c)
       else:
           print("%.2f" %b) 
