a=int(input())
for y in range(1,a+1):
    fact=1
    b=int(input())
    for i in range(1,b+1):
        fact=fact*i
    print fact
    
