a=int(input())
for i in range(a):
    x=map(int,raw_input().split())
    n=x.pop(0)
    for k in range(1,1001):
        flag=True
        for j in x:
            flag=flag and (j%k==0)
        if flag:
            div=k
    for j in x:
        print j/div
    print
            
