a=int(input())
for i in range(0,a):
    s_notes=[100,50,10,5,2,1]
    i=int(input())
    n=0
    m=0
    while(i!=0):
        m+=i/s_notes[n]
        i=i%s_notes[n]
        n+=1
    print int(m)    
