a=int(input())
for t in range(0,a):
    n=0
    c1=list(raw_input().split())
    c2=list(raw_input().split())
    for i in c1:
        if i in c2:
            n+=1
        if n>=2:
            break
    if n>=2:
        print "similar"
    else:
        print "dissimilar"
