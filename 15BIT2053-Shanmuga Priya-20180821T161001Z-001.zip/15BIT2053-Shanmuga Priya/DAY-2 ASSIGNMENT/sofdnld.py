a=int(input())
for num in range (0,a):
    num=int(raw_input())
    if(num>10):
        ld=num%10
        while(num >= 10):
            num = num / 10;
            fd = num;
            sum=fd+ld
        print int(sum)
