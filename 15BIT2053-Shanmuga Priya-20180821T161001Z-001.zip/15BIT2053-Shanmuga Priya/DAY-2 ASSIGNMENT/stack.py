for x in range(input()):
    a= raw_input()
    b=[]
    c=[]
    s=""
    for i in range( len(a)):
        if a[i].isalpha():
            b.append(a[i])
        elif (a[i]!='(')and(a[i]!=')'):
            c.append(a[i])
        elif (a[i]==')'):
            b.append(c[len(c)-1])
            del c[len(c)-1]
    for i in b:
        s+=i
    print s
