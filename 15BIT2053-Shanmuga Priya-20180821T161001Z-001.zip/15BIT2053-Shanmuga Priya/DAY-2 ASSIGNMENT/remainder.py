x=int(input())
for y in range (1,x+1):
    a,b=raw_input("").split()
    a=int(a)
    b=int(b)
    if(a>b)and(a!=0):
        c=a%b
        print int(c)
    else:
        print int(a)
        
