a=int(input())
while(a!=0):
    n=int(input())
    sqrt=n**0.5
    print (int(sqrt))
    a-=1
