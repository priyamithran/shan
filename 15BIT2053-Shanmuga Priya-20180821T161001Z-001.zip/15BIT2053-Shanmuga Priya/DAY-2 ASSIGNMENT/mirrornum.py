print int(raw_input())
