a=int(input())
for x in range (0,a):
    b=raw_input()
    c=0
    for j in range (0,len(b)):
        if(b[j]=='4'):
            c+=1
    print c
            
