a=int(input())
for i in range(0,a):
    b=int(input())
    if(b<10):
        print "What an obedient servant you are!"
    else:
        print -1
    a-=1
        
