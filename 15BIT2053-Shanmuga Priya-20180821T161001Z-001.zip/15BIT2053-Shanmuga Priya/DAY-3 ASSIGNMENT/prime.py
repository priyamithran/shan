def isprime(n):
    for x in range(2,n/2):
        if (n%x==0):
            return 'no'
    return 'yes'
for x in range(input()):
    print isprime(input()) 
 
