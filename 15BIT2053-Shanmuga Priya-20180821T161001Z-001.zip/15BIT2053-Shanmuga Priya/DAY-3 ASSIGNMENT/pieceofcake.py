a=int(input())
for i in range (0,a):
    b=raw_input()
    j=0
    for x in b:
        r=b.count(x)
        v=len(b)-r
        if(r==v):
            j=1
            break;
    if(j==1):
       print "YES"
    else:
        print "NO"
