a=int(input())
for i in range(0,a):
    choice=raw_input().lower()
    print ({"b":'BattleShip',"c":'Cruiser',"d":'Destroyer',"f":'Frigate'}[choice])
