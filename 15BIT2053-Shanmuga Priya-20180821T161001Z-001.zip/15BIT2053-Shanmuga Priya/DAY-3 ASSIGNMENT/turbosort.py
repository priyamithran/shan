x=int(input())
y=[]
for i in range(0,x):
    y.append(input())
y.sort()
for i in y:
    print i
