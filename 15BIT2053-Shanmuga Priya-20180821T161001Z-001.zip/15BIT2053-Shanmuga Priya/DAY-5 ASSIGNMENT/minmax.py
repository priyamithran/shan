a=int(input())
for i in range (0,a):
    n=int(raw_input())
    m=map(int,raw_input().split())
    print min(m)*(n-1)
