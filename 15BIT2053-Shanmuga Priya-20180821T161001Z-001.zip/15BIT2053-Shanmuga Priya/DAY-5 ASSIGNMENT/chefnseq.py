a=int(input())
for i in range (0,a):
    x=int(raw_input())
    l1=map(int,raw_input().split())
    sy=int(raw_input())
    l2=map(int,raw_input().split())
    c=len(l2)
    f=0
    for r in range(c):
        if(l2[r] in l1):
            f=0
        else:
            f=1
            break
    if f==0:
        print "Yes"
    else:
        print "No"
    
