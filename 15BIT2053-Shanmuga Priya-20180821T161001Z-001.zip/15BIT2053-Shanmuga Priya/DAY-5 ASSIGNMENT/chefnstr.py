s=str(raw_input()).strip()
c=ch=che=chef=0
for i in s:
    if i=="C":
        c+=1
    elif i=="H" and ch<c:
        ch+=1
    elif i=="E" and che<ch:
        che+=1
    elif i=="F" and chef<che:
        chef+=1
print chef 
