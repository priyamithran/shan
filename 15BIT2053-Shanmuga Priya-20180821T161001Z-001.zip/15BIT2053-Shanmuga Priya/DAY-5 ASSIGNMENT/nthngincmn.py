a=int(input())
l=[]
for i in range (0,a):
    x,y=map(int,raw_input().strip().split(" "))
    a=set(map(int,raw_input().strip().split(" ")))
    b=set(map(int,raw_input().strip().split(" ")))
    l.append(len(a&b))
for j in l:
    print j
    
