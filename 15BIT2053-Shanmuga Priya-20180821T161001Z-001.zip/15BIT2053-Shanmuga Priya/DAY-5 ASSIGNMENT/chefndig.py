a=int(input())
for a in range(0,a):
    i=raw_input()
    if(i.count('0')==1 and i.count('1')>=1) or (i.count('1')==1 and i.count('0')>=1) or (i.count('0')==1 and i.count('1')==0) or(i.count('1')==1 and i.count('0')==0):
        print "Yes"
    else:
        print "No"
 
    
