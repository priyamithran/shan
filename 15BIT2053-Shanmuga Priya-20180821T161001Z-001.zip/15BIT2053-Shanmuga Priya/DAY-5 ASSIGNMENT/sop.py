a=int(input())
for i in range(0,a):
    sum1=0
    x,y=map(int,raw_input().split())
    for j in range(x,y+1):
        str1=str(j)
        if(str1==str1[::-1]):
            sum1+=j
    print sum1
