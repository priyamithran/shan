a=int(input())
for i in range (0,a):
    x,y=map(int,raw_input().split())
    c=float(x*y)
    if(x>1000):
        d=(c*0.1)
        z=float(c-d)
        print "%.6f"%z
    else:
        print "%.6f"%c
