a=int(input())
for i in range(0,a):
    n=int(raw_input())
    print ((n/2)+1)
