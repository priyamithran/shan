a,b=map(int,raw_input().split(" "))
c=0
for i in range (0,a):
    n=int(input())
    if(n%b==0):
        c+=1
print c
