a=int(input())
l=raw_input()
l=l.split()
c=0
for i in l:
    if(int(i)%2==0):
        c+=1
    else:
        c-=1
if(c>0):
    print "READY FOR BATTLE"
else:
    print "NOT READY"
    
