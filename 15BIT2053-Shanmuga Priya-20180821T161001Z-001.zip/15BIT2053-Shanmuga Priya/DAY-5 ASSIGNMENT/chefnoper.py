a=int(input())
for i in range(0,a):
    a,b=map(int,raw_input().split())
    if(a>b):
        print ">"
    elif(a<b):
        print "<"
    elif(a==b):
        print "="
